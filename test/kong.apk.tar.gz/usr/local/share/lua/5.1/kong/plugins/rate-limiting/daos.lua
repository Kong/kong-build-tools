return {
  tables = {"ratelimiting_metrics"}
}
