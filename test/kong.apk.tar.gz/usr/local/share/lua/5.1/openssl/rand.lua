local ctx = require"_openssl.rand"

return ctx
