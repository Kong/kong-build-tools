local pkey = require"_openssl.pkey"

return pkey

