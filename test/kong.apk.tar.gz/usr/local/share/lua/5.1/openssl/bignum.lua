local bignum = require"_openssl.bignum"

return bignum
