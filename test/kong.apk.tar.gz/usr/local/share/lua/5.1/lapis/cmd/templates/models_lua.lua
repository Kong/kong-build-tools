return [[local autoload = require("lapis.util").autoload
return autoload("models")
]]
